<?php

return [
    'cron_list'     => [
        // 每分钟
        '*'     => [
            'setJackpotNumber'      => '\app\common\service\util\Cron', // Jackpot数字增长
            'autopay'               => '\app\common\service\util\Cron', // 自动出款

            // 'clearTypingAmountLimit'      => '\app\common\service\util\Cron', // 测试使用

        ],
        // 每几分钟 规定每几分钟执行的带有% 每30分钟
        'i%30'     => [
            'telegramBot'           => '\app\common\service\util\Cron', // Telegram报表
        ],
        // 每天任意时间点 每天23.59
        '23:59'     => [
            'telegramBot'           => '\app\common\service\util\Cron', // 当日最后一次Telegram报表
            // 'betCommission'         => '\app\common\service\util\Cron', // 计算并记录下注佣金
            'backWater'             => '\app\common\service\util\Cron', // 计算并记录亏损返水
            'betAward'              => '\app\common\service\util\Cron', // 计算并记录下注奖励
        ],
        // 每天任意时间点 每天00:01
        '00:01'     => [
            'dataRecord'            => '\app\common\service\util\Cron', // 统计每日盈利
        ],
        // 每天任意时间点 每天00:02
        '00:02'     => [
            'clearTodayProfit'      => '\app\common\service\util\Cron', // 清除当日收益
        ],
        // 每天任意时间点 每天00:10
        '00:10'     => [
            'summaryAdminDaybook'   => '\app\common\service\util\Cron', // 业务员数据统计
            // 'summaryBloggerDaybook'   => '\app\common\service\util\Cron', // 博主数据统计
        ],
        // 每天任意时间点 每天02:30
        '02:30'     => [
            'clearTypingAmountLimit' => '\app\common\service\util\Cron', // 清0.5以下用户提现流水限制
            // 'sendCommission'       => '\app\common\service\util\Cron', // 发放昨日下注佣金
        ],
        // 每天任意时间点 每天00:30
        '00:30'     => [
            // 'makeBotData' => '\app\api\controller\Robot', // 奖励机制
        ],
        // 每小时
        '*:00'     => [
            
        ],
    ],
    'cron_format'   => [
        '*',            // 每分钟
        '*:i',          // 每小时 某分
        'H:i',          // 每天 某时:某分
        '@-w H:i',      // 每周-某天 某时:某分 0=周日
        '*-d H:i',      // 每月-某天 某时:某分
        'm-d H:i',      // 某月-某天 某时:某分
        'Y-m-d H:i',    // 某年-某月-某天 某时：某分
        'i%30',         // 每几分钟 规定每几分钟执行的带有%
    ],
  
];
