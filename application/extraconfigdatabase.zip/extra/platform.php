<?php

return [
  'system_service' => 'https://t.me/FFF20240616',
  'group_telegram' => 'https://t.me/+5UMfo8X1_lIwMjY1',
  'group_whatsapp' => '',
  'group_ins' => 'https://www.instagram.com/brl_hermes/',
  'telegram_chat_id' => '-4659655362',
  'notice' => '<p><span style="color:\\&quot;#ffffff\\&quot;"><strong style="box-sizing: border-box;">Bem-vindo ao Hermes, o parceiro oficial do PG-Slots.&nbsp;</strong></span><strong style="box-sizing: border-box; font-family: &quot;Source Sans Pro&quot;, &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 14px; text-wrap: wrap; background-color: rgb(255, 255, 255); color: rgb(0, 255, 240);">Hermes</strong><span style="color:\\&quot;#ffffff\\&quot;"><strong style="box-sizing: border-box;">&nbsp;é o parceiro oficial do PG-Slots. Convide amigos e ganhe 10 reais cada, além de descontos&nbsp; &nbsp;</strong></span></p>',
];
