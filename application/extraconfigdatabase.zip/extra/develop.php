<?php

return [
  'develop' => [
    'appid' => 'game',
    'secret' => 'b3a45c068c18ed36660c8a98',
  ],
];
