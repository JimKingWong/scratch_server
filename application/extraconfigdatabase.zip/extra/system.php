<?php

return [
  'agent_code_length' => '6',
  'user_code_length' => '8',
  'valid_bet' => '50',
  'valid_recharge' => '20',
  'min_recharge' => '10',
  'withdraw_rate' => '0',
  'min_withdraw' => '11',
  'cpf_status' => '0',
  'auto_pay' => '1',
  'box_typing_multiple' => '1.5',
];
