<?php

return [
  'esconfig' => [
    'host' => 'es-sg-ju33onbk500047x6y.public.elasticsearch.aliyuncs.com',
    'port' => '9200',
    'scheme' => 'http',
    'user' => 'elastic',
    'pass' => 'Bigfan!!',
  ],
  'prefix' => 'hgm',
  'es_table' => [
    2 => 'pg',
    4 => 'pp',
    3 => 'jili',
    23 => 'tada',
    24 => 'cp',
    1000 => 'jdb',
    1 => 'spribe',
    6 => 'mini',
    8 => 'hacksaw',
    5 => 'omg_mini',
    7 => 'omg_crypto',
    0 => 'omg',
  ],
];
