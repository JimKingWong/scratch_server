<?php

return [
    'recharge_channel_rate' => '0.02',
    'withdraw_channel_rate' => '0',
    'game_api_fee' => '0.01',
    'domain' => 'https://api.hms-cop.com',
];