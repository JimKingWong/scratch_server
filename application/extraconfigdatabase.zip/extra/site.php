<?php

return [
  'name' => '我的网站',
  'beian' => '',
  'cdnurl' => '',
  'version' => '1.0.5',
  'timezone' => 'America/Sao_Paulo',
  'forbiddenip' => '',
  'languages' => [
    'backend' => 'zh-cn',
    'frontend' => 'zh-cn',
  ],
  'fixedpage' => 'dashboard',
];
