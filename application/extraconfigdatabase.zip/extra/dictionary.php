<?php

return [
  'categorytype' => [
    'default' => '默认',
    'page' => '单页',
    'article' => '文章',
    'test' => 'Test',
  ],
  'configgroup' => [
    'system' => '系统配置',
    'platform' => '平台配置',
    'es' => 'ES配置',
    'user' => '会员配置',
    'basic' => '基础配置',
    'dictionary' => '字典配置',
  ],
  'attachmentcategory' => [
    'pg' => 'PG游戏目录',
    'pp' => 'PP游戏目录',
    'cp' => 'CP游戏目录',
    'jdb' => 'JDB游戏目录',
    'tada' => 'TADA游戏目录',
  ],
];
